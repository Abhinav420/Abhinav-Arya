﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class User_Reminder : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(path.cpath);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            DropDownList1.Items.Insert(0, "....Select Date...");
            for (int i = 1; i <= 31; i++)
            {

                DropDownList1.Items.Add(i.ToString());
            
            }

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into Reminders values(@User_Id,@Reminder_name,@Reminder_Description,@Date,@Amount)", con);
        cmd.Parameters.AddWithValue("@User_Id", Session["id"].ToString());
        cmd.Parameters.AddWithValue("@Reminder_name", TextBox1.Text);
        cmd.Parameters.AddWithValue("@Reminder_Description", TextBox2.Text);
        cmd.Parameters.AddWithValue("@Date", DropDownList1.SelectedItem.Text.ToString());
        cmd.Parameters.AddWithValue("@Amount", TextBox4.Text );

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            Label1.Text = "Saved Sucessfully";
            con.Close();

        }
        catch (Exception ex)
        {
            Label1.Text = ex.ToString();
        
        }

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        GridView1.Visible = true;
    }
}
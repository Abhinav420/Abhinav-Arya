﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class Register : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(path.cpath);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int f = 1;
        {// checking 
            SqlCommand cmd = new SqlCommand("select * from user2", con);
            try
            {
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    if (dr["Email_id"].ToString() == TextBox_email_id.Text.Trim())
                    {

                        f = 0;
                  
                    
                   }
                              
                
                }
                con.Close();
            }
            catch (Exception ex)
            {
                Label1.Text = ex.ToString();

            }

        }// end of checking 


        if (f == 1)
        {


            { // insertion 
                SqlConnection con2 = new SqlConnection(path.cpath);
                SqlCommand cmd = new SqlCommand("insert into user2 values(@Name,@Email_Id,@Phone_no,@Password)", con2);
                cmd.Parameters.AddWithValue("@Name", Textbox_name.Text.Trim());
                cmd.Parameters.AddWithValue("@Email_Id", TextBox_email_id.Text.Trim());
                cmd.Parameters.AddWithValue("@Phone_no", TextBox_phone_no.Text.Trim());
                cmd.Parameters.AddWithValue("@Password", TextBox_pass.Text.Trim());
                try
                {
                    con2.Open();
                    cmd.ExecuteNonQuery();
                    Label1.Text = " Registered Sucessfully..";
                    con2.Close();
                }
                catch (Exception ex)
                {

                    Label1.Text = ex.ToString();

                }


            }// insertion 
        }
        else
        {

            Label1.Text = " Already Registered ....";
        
        }



    }
}
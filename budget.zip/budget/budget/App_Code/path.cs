﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for path
/// </summary>
public class path
{
    public static string cpath = @"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\budget\App_Data\budget.mdf;Integrated Security=True;User Instance=True";

}
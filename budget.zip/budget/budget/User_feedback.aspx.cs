﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class User_feedback : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(path.cpath);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into feedback values(@feedback,@User_Id)", con);
        cmd.Parameters.AddWithValue("@feedback", TextBox1.Text );
        cmd.Parameters.AddWithValue("@User_Id", Session["id"].ToString ());
        
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        Label1.Text  = "Saved Sucessfully";


        }

        catch (Exception ex)
        {
            Label1.Text = ex.ToString();
        }

    }
}
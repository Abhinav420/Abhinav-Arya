﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Login_ : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(path.cpath);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox2.Text == "Admin" && TextBox3.Text == "12345")
        {
            Session["user"] = "Admin";
            Response.Redirect("Admin_Home.aspx");

        }
        else
        {
            int f = 1;
            SqlCommand cmd = new SqlCommand("select * from user2", con);
            try
            {
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    if (TextBox2.Text == dr["Email_Id"].ToString() && TextBox3.Text == dr["Password"].ToString())
                    {

                        Session["user"] = dr["Name"].ToString();
                        Session["id"] = dr["Email_Id"].ToString();
                        f = 0;
                    
                    }
                
                }
                con.Close();
            }
            catch (Exception xe)
            {

                Label1.Text = xe.ToString();
            
            }

            if (f == 0)
            {


                Response.Redirect("User_Home.aspx");

            }
            else
            {

                Label1.Text = "Already Registered";
            }



        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class User_Ocassional_budegt : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox5_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string excep = "all";
        int inc=0,ex1=0,ex2=0,ex3=0,ex4=0,ex5=0,ex6 =0,ex7=0;
        try
        {
             inc = int.Parse(TextBox1.Text.Trim());
             ex1 = int.Parse(TextBox2.Text.Trim());
             ex2 = int.Parse(TextBox3.Text.Trim());
             ex3 = int.Parse(TextBox4.Text.Trim());
             ex4 = int.Parse(TextBox5.Text.Trim());
             ex5 = int.Parse(TextBox6.Text.Trim());
             ex6 = int.Parse(TextBox7.Text.Trim());
             ex7 = int.Parse(TextBox8.Text.Trim());



        }
        catch (Exception ex)
        {

            excep = ex.ToString();
        
        }

        if (excep == "all")
        {

            int sav = inc - (ex1 + ex2 + ex3 + ex4 + ex5+ex6+ex7);



            Label1.Text = sav.ToString();

            string[] x = new string[7] {"Fooding","Clothing","Life Style","Fuel","Rent","Bills","Extra" };

            int[] y = new int[7] { ex1, ex2, ex3, ex4, ex5, ex6, ex7 };

            Chart1.Series[0].Points.DataBindXY(x, y);







        }
        else
        {

            Label1.Text = " Please enter the correct amount";
        }



    }
}
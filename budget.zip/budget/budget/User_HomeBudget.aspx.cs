﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class User_HomeBudget : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(path.cpath);
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            Label1.Text = DateTime.Now.Day.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString();
            DropDownList1.Items.Insert(0, "................Select Budget.............");
            SqlCommand cmd = new SqlCommand("select * from Budget", con);
            try
            {
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    if (dr["User_Id"].ToString() == Session["id"].ToString())
                    {

                        DropDownList1.Items.Add(dr["Budget_Id"].ToString());

                    }

                }

                con.Close();
            }
            catch (Exception ex)
            {

                Label2.Text = ex.ToString();
            }



        }
        //{

        //    string str = Label4.Text;
        //    Response.Redirect("user_Homebudget.aspx");
        //    {
        //        int sum = 0;
        //        SqlCommand cmd = new SqlCommand("select * from Income", con);
        //        try
        //        {
        //            con.Open();
        //            SqlDataReader dr = cmd.ExecuteReader();
        //            while (dr.Read())
        //            {

        //                if (dr["Budget_id"].ToString() == str)
        //                {

        //                    sum = sum + int.Parse(dr["Income_Amount"].ToString());

        //                }



        //            }
        //            con.Close();



        //        }
        //        catch (Exception ex)
        //        {
        //            Label2.Text = "Total Income" + ex.ToString();

        //        }

        //        Label_Income.Text = sum.ToString();

        //    }
        //    {
        //        int sum = 0;
        //        SqlCommand cmd = new SqlCommand("select * from Expences", con);
        //        try
        //        {
        //            con.Open();
        //            SqlDataReader dr = cmd.ExecuteReader();
        //            while (dr.Read())
        //            {

        //                if (dr["Budget_id"].ToString() == str)
        //                {

        //                    sum = sum + int.Parse(dr["Expences_Amt"].ToString());

        //                }



        //            }
        //            con.Close();



        //        }
        //        catch (Exception ex)
        //        {
        //            Label2.Text = "Total Income" + ex.ToString();

        //        }

        //        Label_expences.Text = sum.ToString();


        //    }


        //    Label5.Text = (int.Parse(Label_Income.Text) - int.Parse(Label_expences.Text)).ToString();
        
        
        
        
        
        //}




    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        MultiView1.SetActiveView(View1);
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        SqlDataAdapter dp = new SqlDataAdapter("select * from budget", con);
        try
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            dp.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();


        }
        catch (Exception ex)
        {

            Label2.Text = "Binding Gridview " + ex.ToString();
        }

        MultiView1.SetActiveView(View2);

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into Budget values(@User_Id,@Budget_name,@Budget_Id)", con);
        cmd.Parameters.AddWithValue("@User_Id", Session["id"].ToString());
        cmd.Parameters.AddWithValue("@Budget_name", TextBox1.Text );
        cmd.Parameters.AddWithValue("@Budget_Id", Label1.Text );

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            Label3.Text = " Budget Saved Sucessfully ";
            con.Close();
        }
        catch (Exception ex)
        {

            Label3.Text = "Budget Insertion " + ex.ToString();
        
        }

        Response.Redirect("User_HomeBudget.aspx");

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        MultiView1.SetActiveView(View5);
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        MultiView1.SetActiveView(View4);
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        string str = TextBox_expence_amt.Text.Trim();

        string excep = "all";

        try
        {
            int x = int.Parse(str);
        }
        catch (Exception ex)
        {

            excep = ex.ToString ();
        
        }
        if (excep == "all")
        {


            SqlCommand cmd = new SqlCommand("insert into Expences values(@Expence_name,@Expences_Amt,@Budget_id)", con);
            cmd.Parameters.AddWithValue("@Expence_name", TextBox_Expence_Name.Text);
            cmd.Parameters.AddWithValue("@Expences_Amt", TextBox_expence_amt.Text);
            cmd.Parameters.AddWithValue("@Budget_id", Label4.Text);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                Label_exception_expences.Text = "Saved Sucessfully";


            }

            catch (Exception ex)
            {
                Label_exception_expences.Text = ex.ToString();
            }

            MultiView1.SetActiveView(View3);
            Response.Redirect("User_HomeBudget.aspx");
        }
        else
        {

            Label_exception_expences.Text = " Please enter the amount in correct Number";
        
        
        }

       
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
         string str = TextBox3.Text ;

        string excep = "all";

        try
        {
            int x = int.Parse(str);
        }
        catch (Exception ex)
        {

            excep = ex.ToString ();
        
        }
        if (excep == "all")
        {




            SqlCommand cmd = new SqlCommand("insert into Income values(@Income_name,@Income_Amount,@Budget_id)", con);
            cmd.Parameters.AddWithValue("@Income_name", TextBox2.Text);
            cmd.Parameters.AddWithValue("@Income_Amount", TextBox3.Text);
            cmd.Parameters.AddWithValue("@Budget_id", Label4.Text);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                Label_exception_expences.Text = "Saved Sucessfully";


            }

            catch (Exception ex)
            {
                Label_exception_expences.Text = ex.ToString();
            }

            MultiView1.SetActiveView(View3);
            Response.Redirect("User_HomeBudget.aspx");
        }
        else
        {


            lable_exception_inceome.Text = " Please enter the amount in correct Number";
        
        }

    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        string str = Label4.Text;
       // Response.Redirect("user_Homebudget.aspx");
        {
            int sum = 0;
            SqlCommand cmd = new SqlCommand("select * from Income", con);
            try
            {
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    if (dr["Budget_id"].ToString() == str)
                    {

                        sum = sum + int.Parse(dr["Income_Amount"].ToString());
                    
                    }
                
                
                
                }
                con.Close();



            }
            catch (Exception ex)
            {
                Label2.Text = "Total Income" + ex.ToString();

            }

            Label_Income.Text = sum.ToString();

        }
        {
            int sum = 0;
            SqlCommand cmd = new SqlCommand("select * from Expences", con);
            try
            {
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    if (dr["Budget_id"].ToString() == str)
                    {

                        sum = sum + int.Parse(dr["Expences_Amt"].ToString());

                    }



                }
                con.Close();



            }
            catch (Exception ex)
            {
                Label2.Text = "Total Income" + ex.ToString();

            }

             Label_expences.Text = sum.ToString();

        
        }

        Label5.Text = (int.Parse(Label_Income.Text) - int.Parse(Label_expences.Text)).ToString();
        MultiView1.SetActiveView(View3);

    }


    
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string str  = DropDownList1.SelectedItem.Text.ToString();

        Label4.Text = str;

        {
            int sum = 0;
            SqlCommand cmd = new SqlCommand("select * from Income", con);
            try
            {
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    if (dr["Budget_id"].ToString() == str)
                    {

                        sum = sum + int.Parse(dr["Income_Amount"].ToString());
                    
                    }
                
                
                
                }
                con.Close();



            }
            catch (Exception ex)
            {
                Label2.Text = "Total Income" + ex.ToString();

            }

            Label_Income.Text = sum.ToString();

        }
        {
            int sum = 0;
            SqlCommand cmd = new SqlCommand("select * from Expences", con);
            try
            {
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    if (dr["Budget_id"].ToString() == str)
                    {

                        sum = sum + int.Parse(dr["Expences_Amt"].ToString());

                    }



                }
                con.Close();



            }
            catch (Exception ex)
            {
                Label2.Text = "Total Income" + ex.ToString();

            }

             Label_expences.Text = sum.ToString();
             Label5.Text = (int.Parse(Label_Income.Text) - int.Parse(Label_expences.Text)).ToString();
             MultiView1.SetActiveView(View3);
        }


       

    }
}